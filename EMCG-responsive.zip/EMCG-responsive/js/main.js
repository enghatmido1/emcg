

$(document).ready(function() {
    $(function() {
        $('img.xyz').hover(sourceSwap, sourceSwap);
    });


    $('.next').on('click', function() {
        var currentImg = $('.active');
        var nextImg = currentImg.next();

        if (nextImg.length) {
            currentImg.removeClass('active').css('z-index', -10);
            nextImg.addClass('active').css('z-index', 10);
        }
    });

    $('.prev').on('click', function() {
        var currentImg = $('.active');
        var prevImg = currentImg.prev();

        if (prevImg.length) {
            currentImg.removeClass('active').css('z-index', -10);
            prevImg.addClass('active').css('z-index', 10);
        }
    });
    $('.carousel').carousel({
        interval: 4000
    });


});

var sourceSwap = function() {
    var $this = $(this);
    var newSource = $this.data('alt-src');
    $this.data('alt-src', $this.attr('src'));
    $this.attr('src', newSource);
}

$('.owl-carousel').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    pagination: false,
    autoplay: 1000,
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 3
        },

    }
});


